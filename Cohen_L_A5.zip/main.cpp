#include <iostream>
#include <exception>
#include "LazyBST.h"
#include "Faculty.h"
#include "Student.h"
#include <fstream>
#include <sstream>
#include <vector>

int main(int argc, char **argv){
    
    BST<int> bst;
    BST<Student*> studentBst;
    BST<Faculty*> facultyBst;
    ofstream outFS;


Student* luz = new Student(205, "Luz", "junior", "Anim", 4.0, 616);
Student* yukari = new Student(352, "Yukari", "junior", "Anim", 4.0, 616);
// Faculty* testFac = new Faculty();
Faculty* parker = new Faculty(616, "Peter", "professor", "science");
studentBst.insert(luz);
studentBst.insert(yukari);
facultyBst.insert(parker);
parker->addStudent(yukari->ID);
parker->addStudent(luz->ID);

cout << "What would you like to do? Enter a number from 1-11." << endl;
cout << "1. Print all students and their information (sorted by ascending id #)" << endl;
cout << "2. Print all faculty and their information (sorted by ascending id #)" << endl;
cout << "3. Find and display student information given the student id" << endl;
cout << "4. Find and display faculty information given the faculty id" << endl;
cout << "5. Add a new student" << endl;
cout << "6. Delete a student given the id" << endl;
cout << "7. Add a new faculty member" << endl;
cout << "8. Delete a faculty member given the id. (They must not have any advisees.)" << endl;
cout << "9. Change a student's advisor given the student id and the new faculty id." << endl;
cout << "10. Remove an advisee from a faculty member given the ids" << endl;
cout << "11. Exit" << endl;
bool cont = true;
while (cont == true){
    cout << "What would you like to do? Enter a number from 1-11." << endl;
int choice;
cin >> choice;
switch(choice) {
        case 1:{
            if (studentBst.isEmpty()){
                cout << "There are no students." << endl;
            }
            else{
            cout << "Here is the list of students in ascending ID# order." << endl;
            studentBst.printTreeInOrder();
            }
            break;}
        case 2:{
            if (facultyBst.isEmpty()){
                cout << "There are no faculty members." << endl;
            }
            else{
            cout << "Here is the list of faculty in ascending ID# order." << endl;
            facultyBst.printTreeInOrder();
            }
            break;}
        case 3:{
            cout << "What is the ID number of the student you want to find?" << endl;
            int idnum;
            cin >> idnum;
            Student* compare = new Student(idnum);
            if (studentBst.contains(compare)){
                cout << "Here is that student's information." << endl;
                cout << studentBst.find(compare) << endl;
            }
            else{
                cout << "There is no student with that ID number." << endl;
            }
            delete compare;
            break;}
        case 4:{
            cout << "What is the ID number of the faculty member you want to find?" << endl;
            int idnum;
            cin >> idnum;
            Faculty* compare = new Faculty(idnum);
            if (facultyBst.contains(compare)){
                cout << "Here is that faculty member's information." << endl;
                cout << facultyBst.find(compare) << endl;
            }
            else{
                cout << "There is no faculty member with that ID number." << endl;
            }
            delete compare;
            break;}
        case 5:{
            int ID;
            string name;
            string level;
            string major;
            double GPA;
            int advisor;
            cout << "You are now adding a new student." << endl;
            cout << "What is their ID number?" << endl;
            cin >> ID;
            cout << "What is their name?" << endl;
            cin >> name;
            cout << "What is their level?" << endl;
            cin >> level;
            cout << "What is their major?" << endl;
            cin >> major;
            cout << "What is their GPA?" << endl;
            cin >> GPA;
            cout << "What is their advisor's ID number? (Enter 0 if none)" << endl;
            cin >> advisor;
            if (advisor != 0){
            Faculty* tempAdvisor = new Faculty(advisor);
            if (facultyBst.contains(tempAdvisor) == false){
                cout << "There is no available advisor with that ID number." << endl;
                advisor = 0;
            }
            else{
            facultyBst.find(tempAdvisor)->addStudent(ID);
            }
            delete tempAdvisor;
            }
            Student* temp = new Student(ID, name, level, major, GPA, advisor);
            studentBst.insert(temp);
            cout << "Student added" << endl;
            break;
            }
        case 6:{
            cout << "What is the ID number of the student you want to delete?" << endl;
            int toBeDeleted;
            cin >> toBeDeleted;
            Student* compareS = new Student(toBeDeleted);
            if (studentBst.contains(compareS)){
                int currentAdvisor = studentBst.find(compareS)->advisor;
                cout << "delete node" << endl;
                studentBst.deleteNode(studentBst.find(compareS));

            Faculty* compare = new Faculty(currentAdvisor);
            if (facultyBst.contains(compare)){
                Faculty* fac = facultyBst.find(compare);
                fac->deleteStudent(toBeDeleted);
                cout << "The student has been deleted." << endl;
            }
            delete compare;
            }
            else{
                cout << "There is no student with that ID number." << endl;
            }
            break;}
        case 7:{
            int ID;
            string name;
            string major;
            string level;
            cout << "You are now adding a new faculty member." << endl;
            cout << "What is their ID number?" << endl;
            cin >> ID;
            cout << "What is their name?" << endl;
            cin >> name;
            cout << "What is their major?" << endl;
            cin >> major;
            cout << "What is their level?" << endl;
            cin >> level;
            Faculty* temp = new Faculty(ID, name, level, major);
            facultyBst.insert(temp);
            cout << "Faculty added" << endl;
            break;}
        case 8:{
            cout << "What is the ID number of the faculty member you want to delete?" << endl;
            int toBeDeleted;
            cin >> toBeDeleted;
            Faculty* compare = new Faculty(toBeDeleted);
            if (facultyBst.contains(compare)){
                if (facultyBst.find(compare)->studentIDs->size>0){
                    cout << "You cannot delete a faculty member that still has advisees." << endl;
                }
                else{
                facultyBst.deleteNode(facultyBst.find(compare));
                cout << "The faculty member has been deleted." << endl;
                }
            }
            else{
                cout << "There is no faculty member with that ID number." << endl;
            }
            delete compare;
            break;}
        case 9:{
            int studentID;
            int currentAdvisor;
            int newAdvisor;
            cout << "What is the student's ID number?" << endl;
            cin >> studentID;
            Student* temp = new Student(studentID);
            if (studentBst.contains(temp)){
            currentAdvisor = studentBst.find(temp)->advisor;

            cout << "What is the ID number of the student's new advisor?" << endl;
            cin >> newAdvisor;
            if (newAdvisor == currentAdvisor){
                cout << "New advisor cannot be the same as old advisor." << endl;
                break;
            }

            Faculty* compare2 = new Faculty(newAdvisor);
            if (facultyBst.contains(compare2)){
                studentBst.find(temp)->setNewAdvisor(newAdvisor);
                cout << studentBst.find(temp)->advisor << endl;
                facultyBst.find(compare2)->addStudent(studentID);

                if (currentAdvisor != 0){
                Faculty* compare = new Faculty(currentAdvisor);
                facultyBst.find(compare)->deleteStudent(studentID);
                }
                cout << "Advisor changed" << endl;
            }
            else{
                cout << "There is no faculty with that ID number." << endl;
            }
            delete compare2;
            }
            else{
                cout << "There are no students with that ID number." << endl;
            }
            delete temp;

            break;}
        case 10:{
            int studentID;
            int currentAdvisor;
            cout << "What is the ID number of the advisor?" << endl;
            cin >> currentAdvisor;
            cout << "What is the student's ID number?" << endl;
            cin >> studentID;
            Faculty* compare = new Faculty(currentAdvisor);
            if (facultyBst.contains(compare)){
                facultyBst.find(compare)->deleteStudent(studentID);
                Student* temp = new Student(studentID);
                studentBst.find(temp)->setNewAdvisor(0);
                delete temp;
                cout << "Student removed" << endl;
            }
            else{
                cout << "There is no faculty with that ID number." << endl;
            }
            delete compare;
            break;}
        case 11:{
            cont = false;
            break;}
        default:
            cout << "Invalid choice. Please choose a number from 1 to 11." << endl;
            break;
    }
}
outFS.open("outputFile.txt");

outFS << "Here is the list of students in ID number order." << endl;
studentBst.getAllElements(studentBst.numElements);
 for (int i = 0; i < studentBst.numElements; ++i){
        outFS << studentBst.listOfElements->getAtLocation(i) << endl;
    }
studentBst.listOfElements->clear(studentBst.numElements);

outFS << "Here is the list of faculty in ID number order." << endl;
facultyBst.getAllElements(facultyBst.numElements);
 for (int i = 0; i < facultyBst.numElements; ++i){
        outFS << facultyBst.listOfElements->getAtLocation(i) << endl;
    }
facultyBst.listOfElements->clear(facultyBst.numElements);

outFS.close();
 return 0;
}