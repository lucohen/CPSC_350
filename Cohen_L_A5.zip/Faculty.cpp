#include "Faculty.h"
#include "DblList.h"

//constructs Faculty

Faculty::Faculty(){
      facID = 1972;
        name = "John";
        level = "prof";
        department = "CompSci";
       studentIDs = new DblList<int>;  
}

Faculty::Faculty(int i){
      facID = i;
        name = "temp";
        level = "temp";
        department = "temp";
       studentIDs = new DblList<int>;  
}

Faculty::Faculty(int f, string n, string l, string d){
        facID = f;
        name = n;
        level = l;
        department = d;
       studentIDs = new DblList<int>;
}

//destroys Faculty
Faculty::~Faculty(){
   
}

void Faculty::printFaculty(){
    cout << "ID: " << facID << endl;
    cout << "Name: " << name << endl;
    cout << "Level: " << level << endl;
    cout << "Department: " << department << endl;
    if (studentIDs->front != NULL){
        ListNode<int> *curr = studentIDs->front;
        cout << "Student IDs: " << curr->data;
        while (curr->next != NULL){
            cout << ", ";
            curr = curr->next;
            cout << curr->data; 
        }
        cout << endl;
    }
}

//overloaded <<
ostream& operator<<(ostream& os, const Faculty& faculty) {
    os << "ID: " << faculty.facID << endl;
    os << "Name: " << faculty.name << endl;
    os << "Level: " << faculty.level << endl;
    os << "Major: " << faculty.department << endl;
    if (faculty.studentIDs->front != NULL){
        ListNode<int> *curr = faculty.studentIDs->front;
        os << "Student IDs: " << curr->data;
        while (curr->next != NULL){
            os << ", ";
            curr = curr->next;
            os << curr->data; 
        }
        os << endl;
    }
    return os;
}

//overloaded << for pointers
ostream& operator<<(ostream& os, const Faculty* faculty) {
    os << "ID: " << faculty->facID << endl;
    os << "Name: " << faculty->name << endl;
    os << "Level: " << faculty->level << endl;
    os << "Major: " << faculty->department << endl;
    if (faculty->studentIDs->front != NULL){
        ListNode<int> *curr = faculty->studentIDs->front;
        os << "Student IDs: " << curr->data;
        while (curr->next != NULL){
            os << ", ";
            curr = curr->next;
            os << curr->data; 
        }
        os << endl;
    }
    return os;
}

//add an ID number to the faculty's advisees
void Faculty::addStudent(int i){
    studentIDs->insertBack(i);
}

//delete an ID number from the faculty's advisees
void Faculty::deleteStudent(int i){
    if (studentIDs->find(i)>(-1)){
    studentIDs->removeNode(i);
    }
    else{
        cout << "There is no student with that ID number among the advisees." << endl;
    }
}