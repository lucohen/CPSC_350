#ifndef FACULTY_H
#define FACULTY_H

#include <iostream>
#include <exception>

#include "DblList.h"
#include "Student.h"

using namespace std;

class Faculty{
    public:
    Faculty();
    Faculty(int i);
    Faculty(int i, string n, string l, string d);
    ~Faculty();
        int facID;
        string name;
        string level;
        string department;
        DblList<int> *studentIDs;

        void addStudent(int i);
        void deleteStudent(int i);
        void printFaculty();

        friend ostream& operator<<(ostream& os, const Faculty& faculty);
        friend ostream& operator<<(ostream& os, const Faculty* faculty);


        //overloaded operators for the objects and their pointers
        bool operator>(const Faculty& s){
            if (facID>s.facID){
                return true;
            }
            else
                return false;
        }
        bool operator<(const Faculty& s){
            if (facID<s.facID){
                return true;
            }
            else
                return false;
        }
        bool operator==(const Faculty& s){
            if (facID==s.facID){
                return true;
            }
            else
                return false;
        }
        bool operator<=(const Faculty& s){
            if (facID<=s.facID){
                return true;
            }
            else
                return false;
        }
        bool operator>=(const Faculty& s){
            if (facID>=s.facID){
                return true;
            }
            else
                return false;
        }
        bool operator!=(const Faculty& s){
            if (facID!=s.facID){
                return true;
            }
            else
                return false;
        }

        bool operator>(const Faculty* s){
            if (facID>s->facID){
                return true;
            }
            else
                return false;
        }
        bool operator<(const Faculty* s){
            if (facID<s->facID){
                return true;
            }
            else
                return false;
        }
        bool operator==(const Faculty* s){
            if (facID==s->facID){
                return true;
            }
            else
                return false;
        }
        bool operator<=(const Faculty* s){
            if (facID<=s->facID){
                return true;
            }
            else
                return false;
        }
        bool operator>=(const Faculty* s){
            if (facID>=s->facID){
                return true;
            }
            else
                return false;
        }
        bool operator!=(const Faculty* s){
            if (facID!=s->facID){
                return true;
            }
            else
                return false;
        }
};
#endif