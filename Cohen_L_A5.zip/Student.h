#ifndef STUDENT_H
#define STUDENT_H

#include <iostream>
#include <exception>

#include "DblList.h"

using namespace std;

class Student{
    public:

    Student();
    Student(int i);
    Student(int i, string n, string l, string m, double g, int a);
    ~Student();
        int ID;
        string name;
        string level;
        string major;
        double GPA;
        int advisor;

        void printStudent();
        void setNewAdvisor(int i);

        friend ostream& operator<<(ostream& os, const Student& student);
        friend ostream& operator<<(ostream& os, const Student* studentPtr);
        

        //overloaded operators for the objects and their pointers
        bool operator>(const Student& s)const{
            if (ID>s.ID){
                return true;
            }
            else
                return false;
        }
        bool operator<(const Student& s)const{
            if (ID<s.ID){
                return true;
            }
            else
                return false;
        }
        bool operator==(const Student& s)const{
            if (ID==s.ID){
                return true;
            }
            else
                return false;
        }
        bool operator>=(const Student& s)const{
            if (ID>=s.ID){
                return true;
            }
            else
                return false;
        }
        bool operator<=(const Student& s)const{
            if (ID<=s.ID){
                return true;
            }
            else
                return false;
        }

        bool operator!=(const Student& s)const{
            if (ID!=s.ID){
                return true;
            }
            else
                return false;
        }

        bool operator>(const Student* s)const{
            if (ID>s->ID){
                return true;
            }
            else
                return false;
        }
        
        bool operator<(const Student* s)const{
            if (ID<s->ID){
                return true;
            }
            else
                return false;
        }
        bool operator==(const Student* s)const{
            if (ID==s->ID){
                return true;
            }
            else
                return false;
        }
        bool operator>=(const Student* s)const{
            if (ID>=s->ID){
                return true;
            }
            else
                return false;
        }
        bool operator<=(const Student* s)const{
            if (ID<=s->ID){
                return true;
            }
            else
                return false;
        }

        bool operator!=(const Student* s)const{
            if (ID!=s->ID){
                return true;
            }
            else
                return false;
        }
};

#endif