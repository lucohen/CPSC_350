#ifndef LAZYBST_H
#define LAZYBST_H

#include<iostream>
#include "DblList.h"
#include "Student.h"
#include "Faculty.h"
using namespace std;

template <class T>
class TreeNode{

    public:
        TreeNode();
        TreeNode(T k);
        virtual ~TreeNode();

        T key;
        TreeNode<T> *left;
        TreeNode<T> *right;
};

template <class T>
TreeNode<T>::TreeNode(){
    left = NULL;
    right = NULL;
    key = NULL;
}

template <class T>
TreeNode<T>::TreeNode(T k){
    left = NULL;
    right = NULL;
    key = k;
}

template <class T>
TreeNode<T>::~TreeNode(){
//UNCOMMENT IF KEY IS POINTER TYPE

    // if (key != NULL) {
    //     delete key;
    //     key = NULL;
    // }
    // left = NULL;
    // right = NULL;
}

template <class T>
class BST{
    public:
        BST();
        virtual ~BST();

        int numElements = 0;
        DblList<T> *listOfElements;
        bool beingRemade = false;
        void insert(T value);
        bool contains(T value);//search function
        T find(T value);
        bool deleteNode(T k);
        TreeNode<T> *getSuccessor(TreeNode<T> *d); //d represents node to be deleted

        bool isEmpty();

        T* getMin();
        T* getMax();

        void printTree();
        void recPrint(TreeNode<T> *node);
        void recAddElement(TreeNode<T> *node);
        void getAllElements(int n);
        void printTreeInOrder();
        void recreateTree();
        void destroyTree(TreeNode<T> *node);
        bool checkIfBalanced();
        double getMaxHeight(TreeNode<T> *node);
        void makeNewTree();
        void recMakeNewTree(int lowerBarrier, int mid, int upperBarrier);

    private:
        TreeNode<T> *root;
};

template <class T>
BST<T>::BST(){
    root = NULL; //creating empty tree
    listOfElements = new DblList<T>();
}

template <class T>
BST<T>::~BST(){
    destroyTree(root);
}

template <class T>
void BST<T>::recPrint(TreeNode<T> *node){

    if(node == NULL)
        return;

    cout << node->key << endl;
    recPrint(node->left);
    recPrint(node->right);
}

template <class T>
void BST<T>::printTree(){
    recPrint(root);
}

template <class T>
bool BST<T>::isEmpty(){
    return (root == NULL);
}

template <class T>
T* BST<T>::getMin(){
    if (isEmpty())
        return NULL;

    TreeNode<T> *current = root;

    while(current->left != NULL){
        current = current->left;
    }

    return &(current->key);  // the address, since we are returning the pointer
}

template <class T>
T* BST<T>::getMax(){
    if (isEmpty())
        return NULL;

    TreeNode<T> *current = root;

    while(current->right != NULL){
        current = current->right;
    }

    return &(current->key); // the address, since we are returning the pointer
}

template <class T>
void BST<T>::insert(T value){
    numElements++;
    TreeNode<T> *node = new TreeNode<T>(value);

    if(isEmpty()){
        numElements = 1;
        root = node;
    }
    else{
        //tree was not empty
        TreeNode<T> *current = root;
        TreeNode<T> *parent = NULL;

        while (true){
            parent = current;
            //Need to do this for pointers to compare correctly
            if (*value < current->key){
                //we go left
                current = current->left;
                if(current == NULL){
                    //we found the insertion point
                    parent->left = node;
                    break;
                }
            }
            else{
                //we go right
                current = current->right;
                if(current == NULL){
                    parent->right = node;
                    break;
               }
            }
        }
    }
    //HERE
    if (checkIfBalanced() == false && beingRemade == false){
        //cout << "Have to recreate the tree" << endl;
        recreateTree();
    }
}

template <class T>
bool BST<T>::contains(T value){
    if(isEmpty())
    {cout << "Tree is Empty." << endl;
        return false;}

    TreeNode<T> *current = root;
    while (*value != current->key){
        if(*value < current->key)
            current = current->left;
        else    
            current = current->right;

        if(current == NULL)
            return false;
    }

    return true;
}

template <class T>
T BST<T>::find(T value){

    

    TreeNode<T> *current = root;

    while (*value != current->key){
        if(*value < current->key)
            current = current->left;
        else    
            current = current->right;

    }

    return current->key;
}

template <class T>
bool BST<T>::deleteNode(T k){
numElements--;
    if(isEmpty())
        return false;

    TreeNode<T> *current = root;
    TreeNode<T> *parent = root;
    bool isLeft = true;

    while(current->key != k){
        parent = current;
        //pointer required to work
        if(*k < current->key){
            isLeft = true;
            current = current->left;
        }
        else{
            isLeft = false;
            current = current->right;
        }

        if(current == NULL)
            return false;
    }

    //found the node to be deleted
    //if no children, it's a leaf node
    if (current->left == NULL && current->right == NULL){
        if (current == root){
            root = NULL;
            return true;
        }
        else if (isLeft){
            parent->left = NULL;
        }
        else{
            parent->right = NULL;
        }
    }
/*if node to be deleted has one child*/
    else if(current->right == NULL){
        //node to be deleted has a left child
        if(current == root){
            root = current->left;
        }
        else if(isLeft){
            parent->left = current->left;
        }
        else{
            parent->right = current->left;
        }
    }

    else if(current->left == NULL){
        //node to be deleted has a left child
        if(current == root){
            root = current->right;
        }
        else if(isLeft){
            parent->left = current->right;
        }
        else{
            parent->right = current->right;
        }
    }
    else{

        TreeNode<T> *successor = getSuccessor(current);

        if(current == root)
            root = successor;
        else if (isLeft)
            parent->left = successor;
        else   
            parent->right = successor;
            
        successor->left = current->left;
        current->left = NULL;
        current->right = NULL;
    }
    delete current;
    if (checkIfBalanced() == false){
        //cout << "Have to recreate the tree" << endl;
        recreateTree();
    }
    return true;


}
template <class T>
    TreeNode<T>* BST<T>::getSuccessor(TreeNode<T> *d){
        //d represents the node we are deleting, so we need to find who will take its place

        TreeNode<T> *sp = d;
        TreeNode<T> *successor = d;
        TreeNode<T> *current = d->right;

        while (current != NULL){
            sp = successor;
            successor = current;
            current = current->left;
        }

        //found the successor but we need to check if the successor is a descendant of the right child
        if (successor != d->right){
            sp->left = successor->right;
            successor->right = d->right;
        }
        return successor;
    }

//destroy the entire tree
template <class T>
void BST<T>::destroyTree(TreeNode<T> *node){
    if(node != NULL){
        destroyTree(node->left);
        destroyTree(node->right);
        delete node;
    }
    root = NULL;
}

//recursively store all elements from left to right into listOfElements
template <class T>
void BST<T>::getAllElements(int n){
    
    recAddElement(root);
}

template <class T>
void BST<T>::recAddElement(TreeNode<T> *node){
    if(node->left != NULL) {
        recAddElement(node->left);
    }
    
    listOfElements->insertBack(node->key);

    if (node->right != NULL){
        recAddElement(node->right);
    }
    return;
    
}

//checks that neither side is 1.5 times greater than the other
template <typename T>
bool BST<T>::checkIfBalanced(){
    double left = 0;
    double right = 0;

    if (root->left != NULL){
        left = getMaxHeight(root->left);
    }
    if (root->right != NULL){
        right = getMaxHeight(root->right);
    }
    
    if (left <= 1 && right<=1){
        return true;
    }
    return (left*1.5 > right && right*1.5 > left);
}
template <typename T>
double BST<T>::getMaxHeight(TreeNode<T>* root) {
if (root == NULL) {
return 0;
}
double leftHeight = getMaxHeight(root->left);
double rightHeight = getMaxHeight(root->right);
return 1.0 + max(leftHeight, rightHeight);
}

//creates a new tree
template <typename T>
void BST<T>::makeNewTree() {
        int middle = numElements/2;
        recMakeNewTree(0, middle, numElements);
    
}
//recursively split the tree in half and make the median the root
template <typename T>
void BST<T>::recMakeNewTree(int lowerBarrier, int mid, int upperBarrier){
    insert(listOfElements->getAtLocation(mid));
    if (mid/2 == 0){
        insert(listOfElements->getAtLocation(0));
    }
    if (mid-lowerBarrier > 1){
        recMakeNewTree(lowerBarrier, mid-((mid-lowerBarrier)/2), mid);
    }
    if (upperBarrier-mid > 1){
        recMakeNewTree(mid, mid + ((upperBarrier-mid)/2), upperBarrier);
    }
    
    return;
}

//prints the elements of the tree in order
template <typename T>
void BST<T>::printTreeInOrder(){
    getAllElements(numElements);
 for (int i = 0; i < numElements; ++i){
        cout << listOfElements->getAtLocation(i) << endl;
    }
listOfElements->clear(numElements);
}

//calls all methods needed to fully recreate the tree
template <typename T>
void BST<T>::recreateTree(){
    beingRemade = true;
getAllElements(numElements);
destroyTree(root);
makeNewTree();
listOfElements->clear(numElements);
beingRemade = false;
}

#endif