Assignment: Cohen_L_A5
Author: Lucas Cohen

This program utilizes a self-balancing binary search tree to organize the data of students and faculty members, allowing the user to insert, delete, and get information on them, in addition to updating the student's advisors and vice-versa. The students and faculty are organized based on their ID numbers. The bst is a "lazy bst", meaning it is completely destroyed and rebuilt if it becomes unbalanced. The user can interact with the data by inputting a number from 1 to 11 and providing the necessary information. After quitting, the data of the students and faculty will be outputted to an output file in ascending ID number order.

Files included:
 - DblList.h
 - Faculty.cpp
 - Faculty.h
 - LazyBST.h
 - ListNode.h
 - main.cpp
 - Student.cpp
 - Student.h
 - README.md

Help Sources
 - https://www.tutorialspoint.com/cplusplus/cpp_overloading.htm
 - I used ChatGPT to figure out how to overload the << operator, so that 
 the student and faculty data would be printed after cout << or outFS <<.

compile commands: 
 - g++ *.cpp
 - ./a.out

