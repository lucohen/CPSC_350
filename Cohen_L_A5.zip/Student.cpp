#include "Student.h"


//constructs Student

Student::Student(){
       ID = 2417878;
        name = "Jeff";
        level = "Senior";
        major = "CS";
        GPA = 3.6;
        advisor = 63; 
}

Student::Student(int i){
       ID = i;
        name = "temp";
        level = "temp";
        major = "temp";
        GPA = 0.0;
        advisor = 0; 
}

Student::Student(int i, string n, string l, string m, double g, int a){
        ID = i;
        name = n;
        level = l;
        major = m;
        GPA = g;
        advisor = a;
}

//destroys Student
Student::~Student(){
   
}

void Student::printStudent(){
    cout << "ID: " << ID << endl;
    cout << "Name: " << name << endl;
    cout << "Level: " << level << endl;
    cout << "Major: " << major << endl;
    cout << "GPA: " << GPA << endl;
    cout << "Advisor ID: " << advisor << endl;
}

void Student::setNewAdvisor(int i){
    advisor = i;
}

//overloaded <<
ostream& operator<<(ostream& os, const Student& student) {
    os << "ID: " << student.ID << endl;
    os << "Name: " << student.name << endl;
    os << "Level: " << student.level << endl;
    os << "Major: " << student.major << endl;
    os << "GPA: " << student.GPA << endl;
    os << "Advisor: " << student.advisor << endl;
    return os;
}

//overloaded << for pointers
ostream& operator<<(ostream& os, const Student* student) {
    os << "ID: " << student->ID << endl;
    os << "Name: " << student->name << endl;
    os << "Level: " << student->level << endl;
    os << "Major: " << student->major << endl;
    os << "GPA: " << student->GPA << endl;
    os << "Advisor: " << student->advisor << endl;
    return os;
}



