#include "Model.h"

Model::Model(){ //constructor
    
}


Model::~Model(){ //destructor
    
}

string Model::translateSingleConsonant(char cons) {
    //If it is the first char in the sentence, it will be capitalized, so we need to make a lowercase version
    //converts from char to string
    string lowerStr = string(1, tolower(cons)); //lowercase version
    string str = string(1,cons); //as-is
    return str + "o" + lowerStr; //returns a string that is the character doubled with an o between them
}

string Model::translateSingleVowel(char vow) {
    //if it is a vowel, nothing changes, so this just converts it to a string so that it can be used later
    return string(1, vow);
}