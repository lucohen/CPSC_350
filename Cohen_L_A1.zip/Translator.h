#ifndef TRANSLATOR_H
#define TRANSLATOR_H

#include<iostream>
#include <exception>
#include "Model.h"

using namespace std;

class Translator{

    public:
        Translator(); //constructor
        ~Translator(); //destructor

        //translator methods
        string translateEnglishWord(string word);
        string translateEnglishSentence(string sentence);
    
        

    private:
        Model *model; //model pointer
};

#endif