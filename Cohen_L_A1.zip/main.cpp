#include "Model.h"
#include "Translator.h"
#include "FileProcessor.h"

int main(int argc, char **argv){

    Model *model = new Model;
    Translator *translator = new Translator;
    FileProcessor *fileProcessor = new FileProcessor;

    
    fileProcessor->processFile("inputFile.txt", "outputFile.html");

    
    
    delete model;
    delete translator;
    delete fileProcessor;
    return 0;
}