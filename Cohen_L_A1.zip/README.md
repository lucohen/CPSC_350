Assignment: Cohen_L_A1
Author: Lucas Cohen

This program takes the string contents of an input file, inputFile.txt, and creates an html document with outputFile.html that contains the string's translation into the robber language. The robber language doubles consonants and places an 'o' between them, while keeping vowels the same.

Files included:
 - FileProcessor.cpp
 - FileProcessor.h
 - Model.cpp
 - Model.h
 - Translator.cpp
 - Translator.h
 - main.cpp
 - inputFile.txt
 - README.md

Help sources:
 - https://www.geeksforgeeks.org/how-to-convert-a-single-character-to-string-in-cpp/
 - https://www.geeksforgeeks.org/getline-string-c/
 - https://html.com/#tutorial

compile commands: 
 - g++ *.cpp
 - ./a.out
