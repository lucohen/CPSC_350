#include "Translator.h"
#include "Model.h"

//constructs translator
Translator::Translator(){
   model = new Model;
}

//destroys translator
Translator::~Translator(){
    delete model;
}

string Translator::translateEnglishWord(string word) {
    string final = ""; //this will become the returned string
    for (int i = 0; i < word.size(); ++i) { //loops through every character in the input word.
        //No arrays allowed, so this ensures that any vowel and most punctuation are kept as-is.
        if(tolower(word[i]) == 'a')
            final = final + model->translateSingleVowel(word[i]);
        else if (tolower(word[i]) == 'e')
            final = final + model->translateSingleVowel(word[i]);
        else if (tolower(word[i]) == 'i')
            final = final + model->translateSingleVowel(word[i]);
        else if (tolower(word[i]) == 'o')
            final = final + model->translateSingleVowel(word[i]);
        else if (tolower(word[i]) == 'u')
            final = final + model->translateSingleVowel(word[i]);
        else if (tolower(word[i]) == '!')
            final = final + model->translateSingleVowel(word[i]);
        else if (tolower(word[i]) == '.')
            final = final + model->translateSingleVowel(word[i]);
        else if (tolower(word[i]) == ',')
            final = final + model->translateSingleVowel(word[i]);
        else if (tolower(word[i]) == '\'')
            final = final + model->translateSingleVowel(word[i]);
        else if (tolower(word[i]) == '\"')
            final = final + model->translateSingleVowel(word[i]);
        else if (tolower(word[i]) == '?')
            final = final + model->translateSingleVowel(word[i]);
        else if (tolower(word[i]) == ':')
            final = final + model->translateSingleVowel(word[i]);
        else 
            final = final + model->translateSingleConsonant(word[i]); //translates if the letter is a consonant
    }
    return final;
    }


string Translator::translateEnglishSentence(string sentence) {
    string final = ""; //same logic as in translateEnglish Word
    int start = 0;
    int end = 1;
    for (int i = 0; i < sentence.size(); ++i){ //loops through every character in the input sentence
        if (sentence[i] == ' ') {//if the character is a space, that means a word is finished and can be translated
            end = i; //the location of the last letter of the word is i
            //translate the substring from the word's start location to the location (end - start) chars after it
            final = final + translateEnglishWord(sentence.substr(start, end-start)) + " "; 
            start = i+1; //the next start location will be one character after i.
            }

        //triggers for the last word in the sentence, and doesn't add a space after the word is added.
        else if ((i+1) == sentence.size()){
            end = i;
            final = final + translateEnglishWord(sentence.substr(start, end-start+1));
            start = i+1;
        }
    }
    return final;
}