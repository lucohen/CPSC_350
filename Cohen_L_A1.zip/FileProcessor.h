#ifndef FILEPROCESSOR_H
#define FILEPROCESSOR_H

#include<iostream>
#include <exception>

using namespace std;

class FileProcessor{

    public:
        
        FileProcessor(); //constructor
        ~FileProcessor(); //destructor

        void processFile(string inputFile, string outputFile); //processFile method


    private:
    Model *model; //model pointer
    Translator *translator; //translator pointer
};

#endif