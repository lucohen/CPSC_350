#ifndef MODEL_H
#define MODEL_H

#include<iostream>
#include <exception>

using namespace std;

class Model{

    public:
        Model(); //constructor
        ~Model(); //destructor

        //translator methods
        string translateSingleConsonant(char cons); 
        string translateSingleVowel(char vow);


    private:

};

#endif