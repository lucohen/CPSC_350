#include "Translator.h"
#include "Model.h"
#include "FileProcessor.h"
#include <fstream>

//Constructs FileProcessor
FileProcessor::FileProcessor() {
    translator = new Translator;
    model = new Model;
}

//Destroys FileProcessor
FileProcessor::~FileProcessor() {
    delete translator;
    delete model;
}

void FileProcessor::processFile(string inputFile, string outputFile) {
    //creates input file stream and output file stream
    ifstream inFS;
    ofstream outFS;
    //creates a string to read into from inFS
    string input;

    //opens the files if they aren't already open
    inFS.open(inputFile);
    outFS.open(outputFile);
    if (!inFS.is_open()){
        cout << "could not open input file." << endl;
        return;
    }
    if (!outFS.is_open()){
        cout << "could not open output file." << endl;
        return;
    }
    //loops through each line of the input file and reads it to the string
    while (getline(inFS, input)) {
    inFS >> input;
    }

    //writes to the output file as an html document
    outFS << "<!DOCTYPE html>\n";
    outFS << "<html>\n";
    outFS << "<body>\n";
    outFS << "<p><b>" << input << "</b></p>\n";
    outFS << "<p></p>\n";
    //calls translateEnglishSentence on input when writing to the file
    outFS << "<p><i>" << translator->translateEnglishSentence(input) << "</i></p>\n";
    outFS << "</body>\n";
    outFS << "</html>";
    
    
//closes the files
    inFS.close();
    outFS.close();

    }