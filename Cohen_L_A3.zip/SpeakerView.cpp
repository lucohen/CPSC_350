#include "SpeakerView.h"


using namespace std;
SpeakerView::SpeakerView(){
    
}

SpeakerView::SpeakerView(char o){

    order = o;
}

SpeakerView::~SpeakerView(){
    delete[] heights;
}

void SpeakerView::processFile(string inputFile) {
    //creates input file stream and output file stream
    ifstream inFS;
    //creates a string to read into from inFS
    string input;

    //This first run through the input file finds the amount of rows (aka stack size) and columns
    inFS.open(inputFile);
    if (!inFS.is_open()){
        cout << "could not open input file." << endl;
        return;
    }

    int stackSize = 0;
    string line;
    int stackCount = 0;
    while (getline(inFS, line)) {
        istringstream iss(line);
    double value;
    stackCount = 0;
    while (iss >> value){
        stackCount++;
    }
        stackSize++;
    }
    inFS.close();

    heights = new GenStack<double>[stackSize];

    //opens the files if they aren't already open
    inFS.open(inputFile);
    if (!inFS.is_open()){
        cout << "could not open input file." << endl;
        return;
    }
    
    
    //Now it goes through the input file line by line and puts the numbers into their respective stacks
    while(getline(inFS, input)){
    istringstream iss(input);
    double value;
    int currStack = 0;
    //this while loop pushes the first double in the line to stack 0, the second to stack 1, and so on
    while (iss >> value){
        heights[currStack].push(value);

            //These are test print statements
            //cout << "Pushed " << heights[currStack].peek() << " to stack " << currStack << endl;     
            //cout << "Current stack " << currStack << ": ";
            // heights[currStack].printStack();
            // cout << endl;
        
        currStack++;
    }
    //cout << endl;
    }

    //This was a test print statement. I could not find the error to fix this code.

    // for (int i = 0; i < stackCount; ++i){
    //     cout << "Stack " << i << ": ";
    // while (!heights[i].isEmpty()) {
    //     cout << heights[i].pop() << ", ";
    // }
    // cout << endl;
    // }

MonoStack<double> testStack;
    
    while (!heights[0].isEmpty()) {
        testStack.push(heights[0].pop());
    }
    cout << "In row 0, there are " << testStack.getSize() << " people that can see. Their heights are "; 
        testStack.printStack();
        cout << "inches." << endl;

    cout << endl;
    



   
    inFS.close();

    }