#ifndef MONOSTACK_H
#define MONOSTACK_H

#include<iostream>
#include <exception>

using namespace std;

template <typename T> 
class MonoStack{
    public:

    int count;
    int top;
    int size;
    char order;
    T *myArray;
    MonoStack();
    MonoStack(int N, char o);
    virtual ~MonoStack();
    void push(T c);
    T pop();
    T peek();
    bool isFull();
    bool isEmpty();
    int getSize();
    void printStack();
};

template <typename T>
MonoStack<T>::MonoStack(){
    count = 0;
    size = 0;
    myArray = new T[size];
    order = 'd';
    top = -1;
}
template <typename T>
MonoStack<T>::MonoStack(int N, char o){
    count = 0;
    size = N;
    myArray = new T[size];
    order = o;
    top = -1;
}

template <typename T> 
MonoStack<T>::~MonoStack(){
    delete[] myArray;
}


template <typename T> 
void MonoStack<T>::push(T c) {
    
    if (!isEmpty()){
    if (order == 'i') {
        //pop all values greater than c
        while (top >= 0 && peek() > c) {
            pop();
        }
            
    }
    else if (order == 'd') {
        //pop all values less than c
        while (top >= 0 && peek() < c) {
            pop();
        }
   
    }
    }
        ++count;
        //set the next open spot in the array to be c
        myArray[++top] = c;
}


//     T pop();
template <typename T> 
T MonoStack<T>::pop(){
     if(isEmpty()){
        throw runtime_error("stack is empty, nothing to pop");
    }
    count--;
    return myArray[top--];
    
}
//     T peek();
template <typename T> 
T MonoStack<T>::peek(){
    if(isEmpty()){
        throw runtime_error("stack is empty, nothing to peek");
    }
    return myArray[top];
}
//     bool isFull();
template <typename T> 
bool MonoStack<T>::isFull(){
    return (count == size);
}


//     bool isEmpty();
template <typename T> 
bool MonoStack<T>::isEmpty(){
    return (count == 0);
}

template <typename T> 
int MonoStack<T>::getSize(){
    return count;
}

template <typename T> 
void MonoStack<T>::printStack(){
    for (int i = count-1; i >=0; i--) {
        if (i == 0) {
            cout << "and " << myArray[i] << " ";
        }
        else
            cout << myArray[i] << ", ";
    }
}

#endif