#include "SpeakerView.h"
using namespace std;

int main(int argc, char** argv){
SpeakerView *sv = new SpeakerView();
string inputFile;
cout << "Enter the name of the input file: ";
cin >> inputFile;
//sv->processFile("inputFile.txt");
sv->processFile(inputFile);


delete sv;
return 0;
}

