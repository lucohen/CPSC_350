#ifndef SPEAKERVIEW_H
#define SPEAKERVIEW_H

#include<iostream>
#include <exception>
#include "MonoStack.h"
#include "GenStack.h"
#include <fstream>
#include <sstream>
#include <vector>

using namespace std;

class SpeakerView{

    public:
        SpeakerView();
        SpeakerView(char o); //overloaded constructor
        ~SpeakerView(); //destructor

        
        char order;
        void processFile(string inputFile);
        
        


    
    private:
    //array of MonoStacks
    GenStack<double> *heights;
    MonoStack<double> *goodHeights;
        

};

#endif

