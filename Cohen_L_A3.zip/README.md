Assignment: Cohen_L_A3
Author: Lucas Cohen

This program takes a text file that consists of N lines, with each line consisting of P doubles (representing heights) separated by spaces. It uses a monotonically decreasing stack to determine the number of people in each column of seats that are able to see the speaker clearly, as well as the heights of those people. Those values are printed to the terminal.

Files included:
 - speakerView.cpp
 - speakerView.h
 - main.cpp
 - MonoStack.h
 - GenStack.h
 - inputFile.txt
 - README.md

compile commands: 
 - g++ *.cpp
 - ./a.out

I am pretty confident that my MonoStack template is correct, and It works correctly when I test it with the first column, aka stack 0. However, I was unable to complete this assignment due to a problem with creating the subsequent stacks that I couldn't solve. For some reason, entries in these stacks would be replaced by some of the doubles at the end of previous stacks, and I have no idea how to fix it. So as it stands, this code only works with one column of people.
