#ifndef GENSTACK_H
#define GENSTACK_H

#include<iostream>
#include <exception>

using namespace std;

template <typename T> 
class GenStack{
    public:

    int count;
    int top;
    int size;
    char order;
    T *myArray;
    GenStack();
    GenStack(int N, char o);
    virtual ~GenStack();
    void push(T c);
    T pop();
    T peek();
    bool isFull();
    bool isEmpty();
    int getSize();
    void printStack();
};

template <typename T>
GenStack<T>::GenStack(){
    count = 0;
    size = 0;
    myArray = new T[size];
    order = 'd';
    top = -1;
}
template <typename T>
GenStack<T>::GenStack(int N, char o){
    count = 0;
    size = N;
    myArray = new T[size];
    order = o;
    top = -1;
}

template <typename T> 
GenStack<T>::~GenStack(){
    delete[] myArray;
}


template <typename T> 
void GenStack<T>::push(T c) {
        ++count;
        myArray[++top] = c;
}


//     T pop();
template <typename T> 
T GenStack<T>::pop(){
     if(isEmpty()){
        throw runtime_error("stack is empty, nothing to pop");
    }
    count--;
    return myArray[top--];
    
}
//     T peek();
template <typename T> 
T GenStack<T>::peek(){
    if(isEmpty()){
        throw runtime_error("stack is empty, nothing to peek");
    }
    return myArray[top];
}
//     bool isFull();
template <typename T> 
bool GenStack<T>::isFull(){
    return (count == size);
}


//     bool isEmpty();
template <typename T> 
bool GenStack<T>::isEmpty(){
    return (count == 0);
}

template <typename T> 
int GenStack<T>::getSize(){
    return count;
}

template <typename T> 
void GenStack<T>::printStack(){
    for (int i = count-1; i >=0; i--) {
        cout << myArray[i] << ", ";
    }
}

#endif