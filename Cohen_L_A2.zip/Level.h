#ifndef LEVEL_H
#define LEVEL_H

#include <iostream>
#include "Mario.h"
#include "Object.h"
using namespace std;

class Level{
    public:
        Level(int s, Mario *m);
        ~Level();

        Mario *mario;
        int size;
        int levelNum;
        bool validLevel;


        Object **level;

        void buildLevel(int pCoins, int pNone, int pGoombas, int pKoopas, int pMushrooms);
        void buildLastLevel(int pCoins, int pNone, int pGoombas, int pKoopas, int pMushrooms);
        string printLevel();
        string showMarioInLevel(int mRow, int mCol);
        void moveMario(string direction);
        string runLevel();


       

};

#endif