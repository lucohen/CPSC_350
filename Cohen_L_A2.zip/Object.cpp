#include "Object.h"

Object::Object(){
    type = "none";
    letter = 'x';
}

Object::Object(string t, char c){
    type = t;
    letter = c;
}

Object::~Object(){
    
}

string Object::getType(){
    return type;
}

void Object::setChance(int chance){
    chanceOfAppearing = chance;
}

char Object::getLetter(){
    return letter;
}