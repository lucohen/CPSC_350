#include "Level.h"
#include "Object.h"
#include "Mario.h"


Level::Level(int d, Mario *m){ //Level constructor (always overloaded)
    size = d;
    level = new Object*[size];
    for (int i = 0; i < size; ++i) {
        level[i] = new Object[size];
    }
    validLevel = false;
    mario = m;
}

Level::~Level(){ //Level destructor
    for (int i = 0; i < size; ++i) {
        delete[] level[i];
    }
    delete[] level;
    delete mario;
}

//Creates the level that will be used until Mario beats it.
void Level::buildLevel(int pCoins, int pNone, int pGoombas, int pKoopas, int pMushrooms){
    //create 5 "segments" based on each object's chance of appearing
    int coinMax = pCoins;
    int noneMax = coinMax + pNone;
    int goombaMax = noneMax + pGoombas;
    int koopaMax = goombaMax + pKoopas;
    //ensures the percentages add up to 100
    if (pCoins + pNone + pGoombas + pKoopas + pMushrooms != 100) {
        validLevel = false;
    }
    else { //randomly assign an object to each location based on their chance of appearing
    for (int i = 0; i < size; ++i){
        for (int j = 0; j < size; ++j){
            int whichOne = rand() % 100;
            if (whichOne < coinMax){
            level[i][j] = Object("coin", 'c');
            }
            else if (whichOne < noneMax){
            level[i][j] = Object();
            }
            else if (whichOne < goombaMax){
            level[i][j] = Object("goomba", 'g');
            }
            else if (whichOne < koopaMax){
            level[i][j] = Object("koopa", 'k');
            }
            else {
            level[i][j] = Object("mushroom", 'm');
            }
        }
    }
    while (true) { // make sure warp pipe and boss are in different locations
    int pipeRow = rand() % size;
    int pipeCol = rand() % size;
    int bossRow = rand() % size;
    int bossCol = rand() % size;
    
        if (pipeRow != bossRow || pipeCol != bossCol) {

        level[pipeRow][pipeCol] = Object("warp pipe", 'w');
        level[bossRow][bossCol] = Object("boss", 'b');
        break;}
        }
    
    
    validLevel = true;
    }
    
}

//There is no warp pipe in the last level.
void Level::buildLastLevel(int pCoins, int pNone, int pGoombas, int pKoopas, int pMushrooms) {
    srand(time(NULL));
    //create 5 "segments" based on each object's chance of appearing
    int coinMax = pCoins;
    int noneMax = coinMax + pNone;
    int goombaMax = noneMax + pGoombas;
    int koopaMax = goombaMax + pKoopas;
    //ensures the percentages add up to 100
    if (pCoins + pNone + pGoombas + pKoopas + pMushrooms != 100) {
        cout << "No. Bad." << endl;
        validLevel = false;
    }
    else { //randomly assign an object to each location based on their chance of appearing
    for (int i = 0; i < size; ++i){
        for (int j = 0; j < size; ++j){
            int whichOne = rand() % 100;
            if (whichOne < coinMax){
            level[i][j] = Object("coin", 'c');
            }
            else if (whichOne < noneMax){
            level[i][j] = Object();
            }
            else if (whichOne < goombaMax){
            level[i][j] = Object("goomba", 'g');
            }
            else if (whichOne < koopaMax){
            level[i][j] = Object("koopa", 'k');
            }
            else {
            level[i][j] = Object("mushroom", 'm');
            }
        }
    }
     //No warp pipe
    int bossRow = rand() % size;
    int bossCol = rand() % size;
 
    level[bossRow][bossCol] = Object("boss", 'b');
    validLevel = true;
    }
}

string Level::printLevel(){ //returns the level as a square grid
    string grid = "";
    for (int i = 0; i < size; ++i){
        for (int j = 0; j < size; ++j){
                grid = grid + level[i][j].getLetter();
        }
        grid = grid + "\n";
    } 
    return grid; 
}

//printLevel, but now shows Mario's starting location
string Level::showMarioInLevel(int mRow, int mCol) {
    string grid = "";
    for (int i = 0; i < size; ++i){
        for (int j = 0; j < size; ++j){
            if (i == mRow && j == mCol){
                grid = grid + "H";}
            else {
                grid = grid +level[i][j].getLetter();}
        }
        if (i < size-1) {
        grid = grid + "\n";
        }
    }
    return grid;
}

//This method determines Mario's next location and has him interact with the object there
void Level::moveMario(string direction) {
    //Mario will move to one of 4 locations adjacent to his current one
    int nextRow = mario->getRow();
    int nextCol = mario->getCol();

    if (direction == "right") {
        if (nextCol+1 == size) {
        nextCol = 0;
        }
        else {
            nextCol++;
        }
    }
    else if (direction == "down") {
        if (nextRow+1 == size) {
        nextRow = 0;
        }
        else {
            nextRow++;
        }
    }
    else if (direction == "left") {
        if (nextCol == 0) {
        nextCol = size-1;
        }
        else {
            nextCol--;
        }
    }
    else if (direction == "up") {
        if (nextRow == 0) {
        nextRow = size-1;
        }
        else {
            nextRow--;
        }
    }
    //Mario interacts with the object in the location he will move to
    bool turnEmpty = mario->interactWithObject(level[nextRow][nextCol]);
    //If Mario tried and failed to defeat an enemy, the enemy remains in the space
    if (turnEmpty == true) {//Otherwise, the space becomes empty (the object is "none")
        level[nextRow][nextCol] = Object();
    }
    //set Mario's location to the location he moves to
    mario->move(nextRow, nextCol);
    
}

//This method has Mario navigate the level until he beats it or dies.
string Level::runLevel(){
    //create empty string to be returned
    string result = "";
    //make sure Mario doesn't move before the level starts
        mario->setNextLocation(false);
    //loop makes Mario keep moving until the level ends
    while (mario->isGameOver() == false && mario->hasBeatLevel() == false) {
       
        moveMario(mario->getNextLocation());
        //After each move, add mMario's status to the returned string
        result = result + mario->printStatus();
    }
    //Final results of the level
    if (mario->isGameOver() == true) {
        result = result + "Game Over\n";
    }
    else {
        result = result + "Mario beat the level.\n";
        mario->resetBeatLevel();
    }
    return result;
}


