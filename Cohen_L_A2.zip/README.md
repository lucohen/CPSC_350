Assignment: Cohen_L_A2
Author: Lucas Cohen

This program creates an automatically running Mario game with a series of levels displayed as grids. Mario must navigate the levels via randomly generated directions, encountering enemies and power-ups and collecting coins, before either fighting a boss or finding a warp pipe in order to move onto the next level. The program takes the string contents of an input file, inputFile.txt, which is made up of 8 lines: the number of levels, the dimensions of each level, the number of lives Mario starts with, and a percent chance of each type of object appearing that must add up to 100. A display of the levels, followed by a log of Mario's actions as he progresses through the level, are written to an output file, outputFile.txt.

Files included:
 - Mario.cpp
 - Mario.h
 - Level.cpp
 - Level.h
 - Object.cpp
 - Object.h
 - World.cpp
 - World.h
 - main.cpp
 - FileProcessor.cpp
 - FileProcessor.h
 - inputFile.txt
 - README.md

Help sources:
 - https://cplusplus.com/reference/cstdlib/rand/
 - https://stackoverflow.com/questions/5590381/how-to-convert-int-to-string-in-c

compile commands: 
 - g++ *.cpp
 - ./a.out
