#ifndef World_H
#define World_H

#include <iostream>
#include "Level.h"
#include "Mario.h"
using namespace std;

class World{
    public:
        World();
        World(int levelCount, int levelSize, Mario *m);
        ~World();

        int numLevels;

        Level **world;

        void buildWorld(int pCoins, int pNone, int pGoombas, int pKoopas, int pMushrooms);
        void printWorld();
        string showLevel(int i);
        string getLevelWithMario(int i, int mRow, int mCol);
        string runLevel(int i);

    private:


       

        

       

};

#endif