#include "World.h"
#include "Level.h"

World::World(){
world = new Level*[5];
}

World::World(int levelCount, int levelSize, Mario *m){ //Overloaded constructor for World
    numLevels = levelCount;
    world = new Level*[numLevels];
    for (int i = 0; i < levelCount; ++i) {
        world[i] = new Level(levelSize, m);
    }
}

World::~World(){//destructor for World
    for (int i = 0; i < numLevels; ++i) {
        delete[] world[i];
    }
}

//Creates the array of levels
void World::buildWorld(int pCoins, int pNone, int pGoombas, int pKoopas, int pMushrooms) {
    for (int i = 0; i < numLevels; ++i) {
        if (i == numLevels-1) {
            world[i]->buildLastLevel(pCoins, pNone, pGoombas, pKoopas, pMushrooms);
        }
        else
            world[i]->buildLevel(pCoins, pNone, pGoombas, pKoopas, pMushrooms);
    }
}

//prints each level in the world to be shown at game start.
void World::printWorld(){
    for (int i = 0; i < numLevels; ++i) {
        world[i]->printLevel();
        cout << "=================================" << endl;
    }
}

string World::showLevel(int i) {
    return world[i]->printLevel();
    
}

string World::getLevelWithMario(int i, int mRow, int mCol) {
    return world[i]->showMarioInLevel(mRow, mCol);
    
}

string World::runLevel(int i){
    return world[i]->runLevel();
}
