#include "Mario.h"


//constructs Mario

Mario::Mario(int d){
    numLives = d;
    numCoins = 0;
    powerLv = 0;
    gameOver = false;
    beatLevel = false;
    int currRow;
    int currCol;
    string lastAction = "";
    string nextLocation = "stay";
    string nextAction = "";

}

//destroys Mario
Mario::~Mario(){
    
}

//Add a coin to Mario's collection and add a life if he has 20.
void Mario::collectCoin(){
    ++numCoins;
    if (numCoins >= 20) {
        ++numLives;
        numCoins = 0;
    }
}

//Set Mario's location
void Mario::move(int row, int col){
    currRow = row;
    currCol = col;
}

//Power up Mario (called when he eats a mushroom)
void Mario::powerUp(){
    if (powerLv < 2){
        ++powerLv;
    }
}

//Mario loses a life. Game over if he has no more lives to lose.
void Mario::die(){
    if (numLives >= 0){
        --numLives;
    }
    lastAction = lastAction + "Mario has perished.\n";
    if (numLives < 0) {
        gameOver = true;
    }
}

//This happens when Mario loses a fight. He powers down and dies if he is at level 0
void Mario::powerDown(int p){
    if (p == 2 && powerLv > 1) {
        powerLv = 0;
    }
    else if (p == 1 && powerLv > 0){
        --powerLv;
    }
    else
        die();
}

//If the generated number is higher than the enemy's chance of being beaten, Mario kills it
bool Mario::fightEnemy(int enemyPower){
    int winChance = rand()%100;
    if (winChance >= enemyPower) {
        return true;
    }
    else {
        return false;
    }
}

//If this returns true, the space becomes empty
bool Mario::interactWithObject(Object o) {
    if (o.getType() == "coin") { 
        collectCoin();
        lastAction = "Mario collected a coin.\n";
        setNextLocation(true);
        return true;
        
    }
    else if (o.getType() == "mushroom") {
        powerUp();
        lastAction = "Mario ate a mushroom.\n";
        setNextLocation(true);
        return true;
    }
    else if (o.getType() == "goomba") {//If Mario loses, he still moves to the space, but the enemy remains.
        bool won = fightEnemy(20);
        if (won == true) {
            lastAction = "Mario fought a goomba and won.\n";
            setNextLocation(true);
            return true;
            
        }
        else {
            lastAction = "Mario fought a goomba and lost.\n";
            powerDown(1);
            setNextLocation(true);
            return false;
            
        }
    }
    else if (o.getType() == "koopa") {//If Mario loses, he still moves to the space, but the enemy remains.
        bool won = fightEnemy(35);
        if (won == true) {
            lastAction = "Mario fought a koopa and won.\n";
            setNextLocation(true);
            return true;
        }
        else {
            lastAction = "Mario fought a koopa and lost.\n";
            powerDown(1);
            setNextLocation(true);
            return false;
        }
    }
    else if (o.getType() == "boss") {//Mario fights the boss until either of them are dead
        
        bool won = fightEnemy(50);
        if (won == true) {
            lastAction = "Mario fought a boss and won.\n";
            setNextLocation(false);
            beatLevel = true;
            return true;
        }
        else {
            lastAction = "Mario fought a boss and lost.\n";
            powerDown(2);
            setNextLocation(false);
            return false;
            }
        }
    else if (o.getType() == "warp pipe") {
        beatLevel = true;
        lastAction = "Mario found a warp pipe\n";
        nextAction = "Mario will warp.\n";
    }
    else {//If the position is empty, there is nothing to do.
        lastAction = "This position is empty.\n";
        setNextLocation(true);
        return true;
    }
}

//This is what will be written to the output file after every move.
string Mario::printStatus(){
string statusReport = ""; 
statusReport = statusReport + lastAction;
statusReport = statusReport + "Mario is at level " + to_string(powerLv) + ".\n";
if (numLives < 0) {
    statusReport = statusReport + "Mario isn't coming back from this.\n";
}
else {
statusReport = statusReport + "Mario has " + to_string(numLives) + " lives remaining.\n";
}
statusReport = statusReport +  "Mario has " + to_string(numCoins) + " coins.\n";
statusReport = statusReport + nextAction;
statusReport = statusReport + " -----------\n";
return statusReport;
}

//Randomly decide if Mario will next move up, down, left, or right
void Mario::setNextLocation(bool willMove) {
    if (willMove == true){
    int movement = rand() % 4;
    if (movement == 0) {
        nextLocation = "up";
        nextAction = "Mario will move up.\n";
    }
    else if (movement == 1) {
        nextLocation = "right";
        nextAction = "Mario will move right.\n";
    }
    else if (movement == 2) {
        nextLocation = "down";
        nextAction = "Mario will move down.\n";
    }
    else if (movement == 3) {
        nextLocation = "left";
        nextAction = "Mario will move left.\n";
    }
    }
    else {
        nextLocation = "stay";
        nextAction = "Mario will stay put.\n";
    }
}

//The following are methods to get member variables I needed in other classes
string Mario::getNextLocation() {
    return nextLocation;
}

bool Mario::hasBeatLevel() {
    if (beatLevel == true) {
    }
    return beatLevel;
}

int Mario::getCol(){
    return currCol;
}

int Mario::getRow(){
    return currRow;
}
bool Mario::isGameOver() {
    return gameOver;
}

void Mario::resetBeatLevel() {
    beatLevel = false;
}





