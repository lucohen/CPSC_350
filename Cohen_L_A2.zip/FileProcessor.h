#ifndef FILEPROCESSOR_H
#define FILEPROCESSOR_H


#include "Mario.h"
#include "Object.h"
#include "World.h"
#include "Level.h"
#include<iostream>
#include <exception>

using namespace std;

class FileProcessor{

    public:
        
        FileProcessor(); //constructor
        ~FileProcessor(); //destructor

        void processFile(string inputFile, string outputFile); //processFile method


    private:
    Mario *mario;
    Level *level;
    World *world;
    Object *object;
    
};

#endif