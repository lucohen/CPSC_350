
#include "Mario.h"
#include "Object.h"
#include "World.h"
#include "Level.h"
#include "FileProcessor.h"
#include <fstream>

//Constructs FileProcessor
FileProcessor::FileProcessor() {
    
}

//Destroys FileProcessor
FileProcessor::~FileProcessor() {
   delete mario;
}

void FileProcessor::processFile(string inputFile, string outputFile) {
    //creates input file stream and output file stream
    ifstream inFS;
    ofstream outFS;
    //creates a string to read into from inFS
    int fileNum;

    //opens the files if they aren't already open
    inFS.open(inputFile);
    outFS.open(outputFile);
    if (!inFS.is_open()){
        cout << "could not open input file." << endl;
        return;
    }
    if (!outFS.is_open()){
        cout << "could not open output file." << endl;
        return;
    }
        //Read in values from input file
        inFS >> fileNum;
        int numLevels = fileNum;
        inFS >> fileNum;
        int sizeOfLevels = fileNum;
        inFS >> fileNum;
        int marioLives = fileNum;
        inFS >> fileNum;
        int coins = fileNum;
        inFS >> fileNum;
        int nones = fileNum;
        inFS >> fileNum;
        int goombas = fileNum;
        inFS >> fileNum;
        int koopas = fileNum;
        inFS >> fileNum;
        int mushrooms = fileNum;
        mario = new Mario(marioLives);
        level = new Level(sizeOfLevels, mario);
        world = new World(numLevels, sizeOfLevels, mario);
    
    srand(time(NULL));
    mario->move(rand()%level->size, rand()%level->size);
    //Build the world with the specified amount of levels
    if (coins + nones + goombas + koopas + mushrooms == 100) {
    world->buildWorld(coins, nones, goombas, koopas, mushrooms);
    //Print each level
     for (int i = 0; i < world->numLevels; ++i) {
        outFS << "==================================" << endl;
         outFS << world->showLevel(i) << endl;
     }

    //write Mario's progress through each level to the output file
    for (int i = 0; i < world->numLevels; ++i) {
        outFS << "=================================" << endl;
        outFS << "\n BEGINNING LEVEL " << i << endl;
        //Give Mario a new starting location for the next level
     mario->move(rand()%level->size, rand()%level->size);
     outFS << "Level: " << i << endl;
     outFS << "Mario is starting in position (" << mario->currRow << "," << mario->currCol << ")." << endl;
     outFS << "==================================" << endl;
     outFS << world->getLevelWithMario(i, mario->getRow(), mario->getCol()) << endl;
     outFS << "==================================" << endl;
     outFS << world->runLevel(i);
     if (mario->isGameOver() == true) {
        outFS << "Game Over!" << endl;
        break;
     }

    }
    if (mario->isGameOver() == false) {
        outFS << "You beat the game." << endl;
    }

    }


    //If last 5 lines don't add to 100
    else {
        outFS << "last 5 lines must add to 100." << endl;
    }



    if (!inFS.eof()) {
        cout << "Input failure before reaching end of file." << endl;
    }


   
    
    
//closes the files
    inFS.close();
    outFS.close();

    }