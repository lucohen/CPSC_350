#ifndef OBJECT_H
#define OBJECT_H

#include <iostream>

using namespace std;

class Object{
    public:
    Object();
    Object(string t, char c);
    ~Object();

        string type;

        string getType();

        char letter;

        int chanceOfAppearing;

        void setChance(int chance);

        char getLetter();

    private:
        

};

class Enemy: public Object{
    public:
    Enemy(string t, char c);
    ~Enemy();
        int numToBeat;
};


#endif