#ifndef MARIO_H
#define MARIO_H

#include <iostream>
#include "Object.h"

using namespace std;

class Mario{
    public:
        Mario();
        Mario(int d);
        ~Mario();

        int numLives;
        int numCoins;
        int powerLv;
        int currRow;
        int currCol;
        bool gameOver;
        bool beatLevel;
        string lastAction;
        string nextLocation;
        string nextAction;
        
        void setNextLocation(bool willMove);
        bool hasBeatLevel();
        bool isGameOver();
        void collectCoin();
        bool fightEnemy(int w);
        void powerUp();
        void die();
        void move(int r, int c);
        void powerDown(int p);
        bool interactWithObject(Object o);
        string printStatus();
        string getNextLocation();
        int getCol();
        int getRow();
        void resetBeatLevel();

    private:

};

#endif