#include "Mario.h"
#include "Object.h"
#include "World.h"
#include "Level.h"
#include "FileProcessor.h"

int main(int argc, char **argv){
    Mario *mario = new Mario(3);
    Level *level = new Level(5, mario);
    World *world = new World;
    FileProcessor *fileProcessor = new FileProcessor;
    
    fileProcessor->processFile("inputFile.txt", "outputFile.txt");

    
    
    delete level;
    delete world;
    delete fileProcessor;
    return 0;
}