#ifndef LISTQUEUE_H
#define LISTQUEUE_H

#include <iostream>
#include <exception>

using namespace std;

template <typename T>
//Generic Array-based queue
class ListQueue{
    public:
        ListQueue(); //default constructor
        ListQueue(int maxSize); //overloaded constructor
        ~ListQueue(); //destructor

        //core functions
        void insert(T d); //enqueue
        T dequeue(); //remove from the front
        void enqueue(T d);

        //aux/helper functions
        T peek();
        bool isFull();
        bool isEmpty();
        unsigned int getSize();
        void printArray();
        T getCustomer(int c);
        int mSize;
        int front;
        int rear;
        unsigned int numElements;
        T *myQueue;

    private:
        

};

template <typename T>
ListQueue<T>::ListQueue(int maxSize){
    mSize = maxSize;
    front = 0;
    rear = 0;
    numElements = 0;
    myQueue = new T[mSize];
}


template <typename T> 
ListQueue<T>::~ListQueue(){
    delete[] myQueue;
}

template <typename T> 
void ListQueue<T>::insert(T d){
    if(isFull()){
        throw runtime_error("queue is full");
    }

    myQueue[rear++] = d;
    rear %= mSize;
    numElements++;
}
template <typename T> 
T ListQueue<T>::dequeue() {
    if(isEmpty()){
        throw runtime_error("queue is empty, nothing to remove");
    }
    T c = '\0';
    c = myQueue[front++];
    front %= mSize;
    numElements--;
    return c;
}
template <typename T> 
void ListQueue<T>::enqueue(T d){
    if (isFull()){
        throw runtime_error("Queue is full");
    }
    int i = numElements-1;


    myQueue[i+1] = d;
    numElements++;
}

//aux/helper functions
template <typename T> 
T ListQueue<T>::peek(){
    if(isEmpty()){
        throw runtime_error("queue is empty, nothing to peek");
    }
    return myQueue[front];
}
template <typename T> 
bool ListQueue<T>::isFull(){
    return (numElements == mSize);
}
template <typename T> 
bool ListQueue<T>::isEmpty(){
    return (numElements == 0);
}
template <typename T> 
unsigned int ListQueue<T>::getSize(){
    return numElements;
}
template <typename T> 
void ListQueue<T>::printArray(){
    cout << "Q SIZE: " << getSize() << endl;
    cout << "FRONT: " << front << endl;
    cout << "REAR: " << rear << endl;

    for (int i = 0; i < mSize; ++i){
        cout << "Q[" << i << "]: " << myQueue[i];
        if(i != mSize-1){
            cout << " | ";
        }
    }
    cout << endl;
}

template <typename T>
T ListQueue<T>::getCustomer(int c){
return myQueue[c];
}

#endif