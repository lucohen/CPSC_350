#include "Office.h"


//constructs Office

Office::Office(){
        maxIdleTime = 0;
}
Office::Office(int w, int m){
    numWindows = w;
        maxIdleTime = 0;
        maxSize = m;
        windows = new Window*[numWindows];
    for (int i = 0; i < numWindows; ++i) {
        windows[i] = new Window(maxSize);
    }
}

//destroys Office
Office::~Office(){
    delete[] windows;
}

//This method takes in a customer and finds the shortest window in the office to place it in
void Office::placeCustomerInShortestQueue(Customer* c){
    //cout << "placing in shortest queue" << endl;
    int shortest = windows[0]->getSize();
    int shortestWindow = 0;
    for (int i = 0; i < numWindows; ++i) {
        if (windows[i]->getSize() < shortest){
            shortest = windows[i]->getSize();
            shortestWindow = i;
        }
    }
    windows[shortestWindow]->line->insert(c);
}

//Testing purposes
void Office::printInfo(){
    for (int i = 0; i < numWindows; ++i) {
        cout << "Window " << i << ": ";
        windows[i]->printInfo();
    }
}

//Pass a minute for each window in the office
ListQueue<Customer*> *Office::minutePasses(){
    toBeMoved = new ListQueue<Customer*>(maxSize);
    for (int i = 0; i < numWindows; ++i) {
        bool move = windows[i]->minutePasses();
        if (move){
            toBeMoved->insert(windows[i]->leavesWindow());
        }
    }
    return toBeMoved;
}

//find windows that were ever idle over 5 minutes
int Office::windowsIdleOverFive(){
    int w = 0;
    for (int i = 0; i < numWindows; i++){
        if (windows[i]->idleOverFiveMins){
            w++;
        }
    }
    return w;
}

//find which window has had the longest idle time
int Office::longestIdleTime(){
    int w = 0;
    int l = 0;
    for (int i = 0; i < numWindows; i++){
        if (windows[i]->maxIdleTime > w){
            l = windows[i]->maxIdleTime;
        }
    }
    return l;
}

//calculate the total idle time of every window in the office
double Office::totalIdleTime(){
    int t = 0;
    for (int i = 0; i < numWindows; i++){
        t+=windows[i]->totalIdleTime;
    }
    return t;

}