
#include "FileProcessor.h"
#include <fstream>

//Constructs FileProcessor
FileProcessor::FileProcessor() {
    currentTime = 1;
    customers = new DblList<Customer*>;
    serviceCenter = new ServiceCenter;
    finishedCustomers = 0;
    maxCustomers = 0;
}

//Destroys FileProcessor
FileProcessor::~FileProcessor() {
   delete customers;
   delete serviceCenter;
}

void FileProcessor::processFile(string inputFile, string outputFile) {
    //creates input file stream and output file stream
    ifstream inFS;
    ofstream outFS;

    //creates a string to read into from inFS
    string input;
    int fileNum;
    char fileChar;


    //opens the files if they aren't already open
    inFS.open(inputFile);
    if (!inFS.is_open()){
        cout << "could not open input file." << endl;
        return;
    }
    
       
    //loops through each line of the input file
    
    inFS >> fileNum;
    int numRegistrar = fileNum;
    inFS >> fileNum;
    int numCashier = fileNum;
    inFS >> fileNum;
    int numFinAid = fileNum;
        while (inFS >> fileNum) {
    //cout << "Start new loop" << endl;
    int arrivalTime = fileNum;
    //cout << "Arrival Time: " << arrivalTime << endl;
    inFS >> fileNum;
    int numCustomers = fileNum;
    //cout << "Number of Customers: " << numCustomers << endl;
    getline(inFS, input);

    
    for (int i = 0; i < numCustomers; ++i) {
        inFS >> fileNum;
        int registrarTime = fileNum;
        inFS >> fileNum;
        int cashierTime = fileNum;
        inFS >> fileNum;
        int finAidTime = fileNum;
        inFS >> fileChar;
        char firstLoc = fileChar;
        inFS >> fileChar;
        char secondLoc = fileChar;
        inFS >> fileChar;
        char thirdLoc = fileChar;
       Customer *c = new Customer(arrivalTime, registrarTime, cashierTime, finAidTime, firstLoc, secondLoc, thirdLoc);
        customers->insertBack(c);
        // getline(inFS, input);
        // cout << input << endl;
    }

    //cout << customers->getSize() << endl;
    
    //cout << endl;
}

    maxCustomers = customers->getSize();
serviceCenter = new ServiceCenter(numCashier, numFinAid, numRegistrar, maxCustomers);
int i = 1;

//pass a minute until all customers have finished at every window
while (maxCustomers > serviceCenter->finishedCustomers){
    minutePasses(maxCustomers, i);
    i++;
}

outFS.open(outputFile);
outFS << "\nFINAL RESULTS" << endl;

outFS << endl;
outFS << "Cashier's Office:" << endl;
outFS << "Mean student wait time: " << (serviceCenter->totalCashierWait)/maxCustomers << " minutes" << endl;
outFS << "Mean window idle time: " << (serviceCenter->totalCashierIdleTime())/maxCustomers << " minutes" << endl;
outFS << "Longest student wait time: " << serviceCenter->longestCashierWait << " minutes" << endl;
outFS << "Longest window idle time: " << serviceCenter->longestCashierIdleTime() << " minutes" << endl;
outFS << endl;
outFS << "Financial Aid Office: " << endl;
outFS << "Mean student wait time: " << (serviceCenter->totalFinAidWait)/maxCustomers << " minutes" << endl;
outFS << "Mean window idle time: " << (serviceCenter->totalFinAidIdleTime())/maxCustomers << " minutes" << endl;
outFS << "Longest student wait time: " << serviceCenter->longestFinAidWait << " minutes" << endl;
outFS << "Longest window idle time: " << serviceCenter->longestFinAidIdleTime() << " minutes" << endl;
outFS << endl;
outFS << "Registrar's Office:" << endl;
outFS << "Mean student wait time: " << (serviceCenter->totalRegistrarWait)/maxCustomers << " minutes" << endl;
outFS << "Mean window idle time: " << (serviceCenter->totalRegistrarIdleTime())/maxCustomers << " minutes" << endl;
outFS << "Longest student wait time: " << serviceCenter->longestRegistrarWait << " minutes" << endl;
outFS << "Longest window idle time: " << serviceCenter->longestRegistrarIdleTime() << " minutes" << endl;
outFS << endl;
outFS << "Number of students waiting over 10 minutes total across all offices: "
 << serviceCenter->waitTimesOverTen << endl; 
outFS << "Number of windows idle for over 5 minutes across all offices: " 
<< serviceCenter->cashiersIdleOverFive() + serviceCenter->finAidsIdleOverFive() + serviceCenter->registrarsIdleOverFive() << endl;
//closes the files
    inFS.close();
    outFS.close();

    }

    //This method is called each minute 
    void FileProcessor::minutePasses(int m, int currentTime){
        //Place every new customer in their first queue
        if (!customers->isEmpty()){
            //If the current minute matches the minute the customer should enter its first office, put it in the queue
        while (customers->getFront()->entranceTime == currentTime){
            char addTo = customers->getFront()->currentLoc;
            //cout << "add to " << addTo << endl;
            serviceCenter->addCustomerToOffice(addTo, customers->removeFront());
            if (customers->isEmpty()){
                break;
            }
        }
        }
        serviceCenter->minutePasses(m);
        //serviceCenter->printInfo();
        currentTime++;
    }