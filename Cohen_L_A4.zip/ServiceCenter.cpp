#include "ServiceCenter.h"


//constructs ServiceCenter

ServiceCenter::ServiceCenter(){
       
}

ServiceCenter::ServiceCenter(int c, int f, int r, int m){
    cashier = new Office(c, m);
    finAid = new Office(f, m);
    registrar = new Office(r, m);
    toBeMoved;
    maxSize = m;
    finishedCustomers = 0;
    longestCashierWait = 0;
    longestFinAidWait = 0;
    longestRegistrarWait = 0;
    waitTimesOverTen = 0;
}
//destroys ServiceCenter
ServiceCenter::~ServiceCenter(){
    delete cashier;
    delete finAid;
    delete registrar;
    delete toBeMoved;
}

//Testing purposes
void ServiceCenter::printInfo(){
    cout << "\nCashier" << endl;
    cout << "=================" << endl;
    cashier->printInfo();
    cout << "\nFinancial Aid" << endl;
    cout << "=================" << endl;
    finAid->printInfo();
    cout << "\nRegistrar" << endl;
    cout << "=================" << endl;
    registrar->printInfo();
}

//Pass a minute in each office and find customers that are finished at their current window
void ServiceCenter::minutePasses(int maxCustomers){
    toBeMoved = new ListQueue<Customer*>(maxCustomers);
    ListQueue<Customer*> *fromCashier = cashier->minutePasses();
    while (!fromCashier->isEmpty()){
            int l = fromCashier->peek()->waitTimeInLine;
            if (l > longestCashierWait){
                longestCashierWait = l;
            }
            totalCashierWait+=l;
            if (l > 10){
                waitTimesOverTen++;
            }
            toBeMoved->insert(fromCashier->dequeue());
        }
    delete fromCashier;

    ListQueue<Customer*> *fromFinAid = finAid->minutePasses();
    while (!fromFinAid->isEmpty()){
        int l = fromFinAid->peek()->waitTimeInLine;
            if (l > longestFinAidWait){
                longestFinAidWait = l;
            }
            totalFinAidWait+=l;
            if (l > 10){
                waitTimesOverTen++;
            }
            toBeMoved->insert(fromFinAid->dequeue());
        }
    delete fromFinAid;

    ListQueue<Customer*> *fromRegistrar = registrar->minutePasses();
    while (!fromRegistrar->isEmpty()){
        int l = fromRegistrar->peek()->waitTimeInLine;
            if (l > longestRegistrarWait){
                longestRegistrarWait = l;
            }
            totalRegistrarWait+=l;
            if (l > 10){
                waitTimesOverTen++;
            }
            toBeMoved->insert(fromRegistrar->dequeue());
        }
    delete fromRegistrar;

    while (!toBeMoved->isEmpty()){
        //cout << "to be moved to " << toBeMoved->peek()->currentLoc << endl;
        char addTo = toBeMoved->peek()->currentLoc;
        toBeMoved->peek()->resetWaitTime();
        addCustomerToOffice(addTo, toBeMoved->dequeue());
    }
}

//Add customers to their next office
void ServiceCenter::addCustomerToOffice(char c, Customer* s){
    if (c == 'C'){
        cashier->placeCustomerInShortestQueue(s);
    }
    else if (c == 'F'){
        finAid->placeCustomerInShortestQueue(s);
    }
    else if (c == 'R'){
        registrar->placeCustomerInShortestQueue(s);
    }
    else if (c == 'X'){
        delete s;
        finishedCustomers++;
    }
}

//get the amount of windows idle over 5 minutes in each office

int ServiceCenter::cashiersIdleOverFive(){
    return cashier->windowsIdleOverFive();
}

int ServiceCenter::finAidsIdleOverFive(){
    return finAid->windowsIdleOverFive();
}

int ServiceCenter::registrarsIdleOverFive(){
    return registrar->windowsIdleOverFive();
}

//Get the longest window idle times from each office

int ServiceCenter::longestCashierIdleTime(){
    return cashier->longestIdleTime();
}

int ServiceCenter::longestFinAidIdleTime(){
    return finAid->longestIdleTime();
}

int ServiceCenter::longestRegistrarIdleTime(){
    return registrar->longestIdleTime();
}

//Get the total window idle times from each office

double ServiceCenter::totalCashierIdleTime(){
    return cashier->totalIdleTime();
}

double ServiceCenter::totalFinAidIdleTime(){
    return finAid->totalIdleTime();
}

double ServiceCenter::totalRegistrarIdleTime(){
    return registrar->totalIdleTime();
}