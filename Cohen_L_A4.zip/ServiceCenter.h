#ifndef SERVICECENTER_H
#define SERVICECENTER_H

#include <iostream>
#include <exception>
#include "Office.h"
#include "DblList.h"
#include "ListQueue.h"

using namespace std;

class ServiceCenter{
    public:
        ServiceCenter();
        ServiceCenter(int c, int f, int r, int m);
        ~ServiceCenter();

        Office *cashier;
        Office *finAid;
        Office *registrar;
        ListQueue<Customer*> *toBeMoved;
        void printInfo();
        void minutePasses(int maxCustomers);
        void addCustomerToOffice(char c, Customer* s);
        int maxSize;
        int finishedCustomers;
        int longestCashierWait;
        int longestFinAidWait;
        int longestRegistrarWait;
        double totalCashierWait;
        double totalFinAidWait;
        double totalRegistrarWait;
        int waitTimesOverTen;
        int cashiersIdleOverFive();
        int finAidsIdleOverFive();
        int registrarsIdleOverFive();
        int longestCashierIdleTime();
        int longestFinAidIdleTime();
        int longestRegistrarIdleTime();
        double totalCashierIdleTime();
        double totalFinAidIdleTime();
        double totalRegistrarIdleTime();



       

};

#endif