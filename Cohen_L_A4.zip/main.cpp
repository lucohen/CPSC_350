#include "DBlList.h"
#include "ListQueue.h"
#include "FileProcessor.h"
#include "Customer.h"

int main(int argc, char **argv){

    FileProcessor *fileProcessor = new FileProcessor;
    string inputFile;
cout << "Enter the name of the input file: ";
cin >> inputFile;
    fileProcessor->processFile(inputFile, "outputFile.txt");

   
    
    delete fileProcessor;
    return 0;

}