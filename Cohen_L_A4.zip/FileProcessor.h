#ifndef FILEPROCESSOR_H
#define FILEPROCESSOR_H

#include<iostream>
#include <exception>
#include "Customer.h"
#include "DblList.h"
#include "ServiceCenter.h"
#include "ListQueue.h"
#include <fstream>
#include <sstream>
#include <vector>


using namespace std;

class FileProcessor{

    public:
        
        FileProcessor(); //constructor
        ~FileProcessor(); //destructor

        int currentTime;
        int finishedCustomers;
        int maxCustomers;
        void processFile(string inputFile, string outputFile); //processFile method
        void minutePasses(int maxCustomers, int t);


    private:
    DblList<Customer*> *customers;
    ServiceCenter *serviceCenter;
   
};

#endif