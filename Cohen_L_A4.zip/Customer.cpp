#include "Customer.h"


//constructs Customer

Customer::Customer(){
        registrarTime = 0;
        cashierTime = 0;
        finAidTime = 0;
        firstLoc = ' ';
        secondLoc = ' ';
        thirdLoc = ' ';
        finishedAtLocation = false;
}
Customer::Customer(int et, int rt, int ct, int ft, char fl, char sl, char tl){
    entranceTime = et;
    registrarTime = rt;
    cashierTime = ct;
    finAidTime = ft;
    firstLoc = fl;
    secondLoc = sl;
    thirdLoc = tl;
    currentLoc = firstLoc;
    finishedAtLocation = false;
    timeRemainingAtWindow = getTimeAtCurrentLocation(currentLoc);
    waitTimeInLine = 0;


}

//destroys Customer
Customer::~Customer(){
    
}

//Testing purposes
void Customer::printCustomer(){
    cout << registrarTime << " " << cashierTime << " " << finAidTime << " " << firstLoc << " " << 
        secondLoc << " " << thirdLoc << endl;
}

//When a minute passes, reduce the remaining time required at the window
//If there is no more time required, set the customer's location to the next place it needs to go
void Customer::minutePasses(){
    finishedAtLocation = false;
    if (currentLoc == firstLoc){
        if (timeRemainingAtWindow >= 1){
            timeRemainingAtWindow--;
        }
        else{
            currentLoc = secondLoc;
            timeRemainingAtWindow = getTimeAtCurrentLocation(currentLoc);
            finishedAtLocation = true;
        }
    }
    else if (currentLoc == secondLoc){
        if (timeRemainingAtWindow >= 1){
            timeRemainingAtWindow--;
        }
        else{
            currentLoc = thirdLoc;
            timeRemainingAtWindow = getTimeAtCurrentLocation(currentLoc);
            finishedAtLocation = true;
        }
    }
    else if (currentLoc == thirdLoc){
        if (timeRemainingAtWindow >= 1){
            timeRemainingAtWindow--;
        }
        else{
            currentLoc = 'X';
            finishedAtLocation = true;
        }
    }
}

void Customer::increaseWaitTime(){
    waitTimeInLine++;
}

void Customer::resetWaitTime(){
    waitTimeInLine = 0;
}

int Customer::getTimeAtCurrentLocation(char l){
    if (l == 'R'){
        return registrarTime;
    }
    else if (l == 'C'){
        return cashierTime;
    }
    else if (l == 'F'){
        return finAidTime;
    }
    else
        return 0;
}


