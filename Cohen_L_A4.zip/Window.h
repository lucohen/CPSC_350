#ifndef WINDOW_H
#define WINDOW_H

#include <iostream>
#include <exception>
#include "Customer.h"
#include "DblList.h"
#include "ListQueue.h"

using namespace std;

class Window{
    public:
    Window();
    Window(int m);
        ~Window();

        int totalIdleTime;
        int maxIdleTime;
        int maxSize;
        int currentIdleTime;
        bool idleOverFiveMins;
        ListQueue<Customer*> *line;
        int getSize();
        bool minutePasses();
        void printInfo();
        Customer* leavesWindow();


       

};

#endif