#ifndef CUSTOMER_H
#define CUSTOMER_H

#include <iostream>
#include <exception>

using namespace std;

class Customer{
    public:
    Customer();
        Customer(int et, int rt, int ct, int ft, char fl, char sl, char tl);
        ~Customer();
//==========================================UNDO TO HERE==========================================
        int registrarTime;
        int cashierTime;
        int finAidTime;
        char firstLoc;
        char secondLoc;
        char thirdLoc;
        int timeRemainingAtWindow;
        char currentLoc;
        bool finishedAtLocation;
        int entranceTime;
        int waitTimeInLine;

        void printCustomer();
        void minutePasses();
        void increaseWaitTime();
        void resetWaitTime();
        int getTimeAtCurrentLocation(char l);


        


       

};

#endif