Assignment: Cohen_L_A4
Author: Lucas Cohen

This program calculates the efficiency of a service center by calculating the idle times at each office window and the amount of time that students spend waiting in line at each office. The program takes the string contents of an input file given by the user. The first line is the number of windows open at the
registrar, the second line is the number of windows open at the cashier, and the third line is the number of windows open at the financial aid office. The next line will be the minute at which the next students arrive. The next line will be the number of students that arrive at that time. The following lines will be the amount of time each student needs at the registrar, cashier, and financial aid office, respectively, as well as the order they visit them. This is followed by the next clock minute, number of students, etc. The final results will be printed to an output file, outputFile.txt, detailing each office's mean and longest student wait times, their mean and longest window idle times, the number of students waiting over ten minutes across all offices, and the number of windows idle over five minutes across all offices.

Files included:
 - Customer.cpp
 - Customer.h
 - DblList.h
 - ListNode.h
 - ListQueue.h
 - Office.cpp
 - Office.h
 - ServiceCenter.cpp
 - ServiceCenter.h
 - Window.cpp
 - Window.h
 - main.cpp
 - FileProcessor.cpp
 - FileProcessor.h
 - inputFile.txt
 - README.md


compile commands: 
 - g++ *.cpp
 - ./a.out

possible deviation from specs:
    I wrote my code so that the "clock ticks" that determine the time that students first enter a queue were the exact minute that this happens (ex. in the example input file, the first three students get in line at minute 1, and then at minute 9 two more students enter.) However, I'm pretty sure the example output is impossible with this method. I assume there was some part of the instructions that I misinterpreted, but I still believe that my code gives accurate results for what it is meant to do.