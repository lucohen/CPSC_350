#include "Window.h"


//constructs Window

Window::Window(){
        line;
        totalIdleTime = 0;
        maxIdleTime = 0;
        maxSize = 0;
}
Window::Window(int m){
        line = new ListQueue<Customer*>(m);
        totalIdleTime = 0;
        currentIdleTime = 0;
        maxIdleTime = 0;
        maxSize = m;
        idleOverFiveMins = false;
}


//destroys Window
Window::~Window(){
    
}

int Window::getSize(){
        return line->getSize();
}


bool Window::minutePasses(){
        //check if window is idle and increase idle time and possibly max idle time if so
        if (line->isEmpty()){
                totalIdleTime++;
                currentIdleTime++;
                if (currentIdleTime > maxIdleTime){
                        maxIdleTime = currentIdleTime;
                }
                if (currentIdleTime > 5){
                        idleOverFiveMins = true;
                }
        }
        else{
                if (currentIdleTime > maxIdleTime){
                        maxIdleTime = currentIdleTime;
                }
                currentIdleTime = 0;
                //a minute passes for the customer at the window
                line->peek()->minutePasses();
                if (line->peek()->finishedAtLocation){
                        return true;
                }

                //increase the wait time for the customers still waiting
                for (int i = (line->front)+1; i < line->getSize()+line->front; ++i){
                        line->getCustomer(i)->increaseWaitTime();
                }
                
                
        }
        return false;
}

//remove and return the customer in the front of the line
Customer* Window::leavesWindow(){
        return line->dequeue();
}

//testing purposes
void Window::printInfo(){
       cout << line->getSize() << " customers in line. ";
       if (line->getSize()>0){
       cout << "Front customer has " << line->peek()->timeRemainingAtWindow  << " minutes left." << endl; 
       cout << "This customer waited " << line->peek()->waitTimeInLine << " minutes." << endl;
       }
       for (int i = line->front+1; i < line->getSize()+line->front; ++i){
                        cout << "Customer " << i-line->front << " has waited " << line->getCustomer(i)->waitTimeInLine << "=====================================" << endl;
                }
// for (int i = 0; i < line->getSize(); ++i){
//         line->getCustomer(i)->printCustomer();
// }
       cout << endl;
}

