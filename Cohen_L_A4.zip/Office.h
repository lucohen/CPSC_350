#ifndef OFFICE_H
#define OFFICE_H

#include <iostream>
#include <exception>
#include "Window.h"
#include "Customer.h"
#include "DblList.h"
#include "ListQueue.h"

using namespace std;

class Office{
    public:
    Office();
        Office(int w, int m);
        ~Office();

        int numWindows;
        int maxIdleTime;
        int maxSize;
        Window **windows;
        void placeCustomerInShortestQueue(Customer* c);
        ListQueue<Customer*> *minutePasses();
        void printInfo();
        ListQueue<Customer*> *toBeMoved;
        int windowsIdleOverFive();
        int longestIdleTime();
        double totalIdleTime();


       

};

#endif